<?php 
$conn= new mysqli('localhost','root','', 'center_miniproject');

if($conn->connect_error) die($conn->connect_error);


?>