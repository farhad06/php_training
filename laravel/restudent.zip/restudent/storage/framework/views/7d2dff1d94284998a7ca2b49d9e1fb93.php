
<?php $__env->startSection('title','Users'); ?>
<?php $__env->startPush('css'); ?>
<style>
    img {
        height: 70px;
        width: 70px;
        border-radius: 50%;
    }
</style>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<h2 class="text-center mb-3">All User</h2>
<?php if(session('message')): ?>
<div style="float: right;">
    <div class="alert alert-info alert-dismissible fade show" role="alert">
        <strong style="color: black"><?php echo e(session('message')); ?></strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
</div>
<?php endif; ?>
<div class="table table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Age</th>
                <th>Gender</th>
                <th>City</th>
                <th width="25%" class="text-wrap">Address</th>
                <th>Image</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->phone); ?></td>
                <td><?php echo e($user->age); ?></td>
                <td><?php echo e($user->gender); ?></td>
                <td><?php echo e($user->city); ?></td>
                <td><?php echo e($user->address); ?></td>
                <td>
                    <img src="uploads/<?php echo e($user->photo); ?>">
                </td>
                <td>
                    <a href="<?php echo e(url('/deleteuser')); ?><?php echo e($user->id); ?>"><i class="bi bi-trash-fill"
                            style="color: red;font-size:30px"></i></a>
                </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php_tranning\laravel\restudent\resources\views/users.blade.php ENDPATH**/ ?>