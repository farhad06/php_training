
<?php $__env->startSection('title','Users'); ?>
<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<h2 class="text-center mb-3">Bookings</h2>
<?php if(session('message')): ?>
<div style="float: right;" id="resDiv">
    <div class="alert alert-info alert-dismissible fade show" role="alert">
        <strong style="color: black"><?php echo e(session('message')); ?></strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
</div>
<?php endif; ?>
<div class="table table-responsive">
    <table class="table table-bordered border-dark">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>No of Guests</th>
                <th>Date</th>
                <th>Time</th>
                <th>Booking Id</th>
                <th>Message</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->phone); ?></td>
                <td><?php echo e($user->number_guests); ?></td>
                <td><?php echo e($user->date); ?></td>
                <td><?php echo e($user->time); ?></td>
                <td><?php echo e($user->b_id); ?></td>
                <td><?php echo e($user->message); ?></td>
                <td>
                    <a href="<?php echo e(url('/deletebooking')); ?><?php echo e($user->id); ?>"><i class="bi bi-x-octagon-fill" style="color: red; font-size:30px;"></i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php_tranning\laravel\restudent\resources\views/get_booking.blade.php ENDPATH**/ ?>