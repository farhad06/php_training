
<?php $__env->startSection('title','Chefs'); ?>
<?php $__env->startPush('css'); ?>
<style>
    img {
        height: 70px;
        width: 70px;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<h1 class="h2 text-center mb-3">All Chefs</h1>
<div class="table table-responsive">
    <div class="mb-3">
        <?php if(session('message')): ?>
        <div style="float: right;" id="resDiv">
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <strong style="color: black"><?php echo e(session('message')); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
        <?php endif; ?>
        <button type="button" class="btn btn-sm btn-dark shadow-none" data-toggle="modal" data-target="#addChef"><i
                class="bi bi-plus-circle-fill"></i> Add Chef</button>
    </div>
    <div class="table table-responsive">
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>Chef Name</th>
                    <th>Spacilist</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->spacilist); ?></td>
                    <td>
                        <img src="chefs_images/<?php echo e($item->image); ?>">
                    </td>
                    <td>
                        
                        <a href="<?php echo e(url('/editchef')); ?><?php echo e($item->id); ?>"><i class="bi bi-pencil-square"
                                style="color:green; font-size:30px;"></i></a>
                        <a href="<?php echo e(url('/deletechef')); ?><?php echo e($item->id); ?>"><i class="bi bi-trash3-fill"
                                style="color: red; font-size:30px;"></i></a>&nbsp;&nbsp;&nbsp;
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<!-- Add Modal -->
<div class="modal fade" id="addChef" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-center h4" id="exampleModalLabel">Add Chef</h5>
                <button type="button" class="shadow-none close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(url('/addchef')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="" class="form-label"><strong>Chef Name</strong></label>
                        <input type="text" name="c_name" class="form-control shadow-none">
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label"><strong>Spacilist</strong></label>
                        <input type="text" name="c_spacilist" class="form-control shadow-none">
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label"><strong>Item Image</strong></label>
                        <input type="file" name="c_image" class="form-control shadow-none">
                    </div>
                    <div>
                        <button type="submit" class="btn btn-sm btn-dark shadow-none">ADD CHEF</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php_tranning\laravel\restudent\resources\views/get_all_chefs.blade.php ENDPATH**/ ?>