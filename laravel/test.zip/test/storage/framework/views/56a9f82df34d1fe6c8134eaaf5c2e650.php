
<?php $__env->startSection('title',"Index"); ?>
<?php $__env->startSection('content'); ?>
<div class="mt-3">
    <a href="<?php echo e(url('/add')); ?>" class="btn btn-sm btn-primary shadow-none">ADD</a>
    <h1 class="text-center"><u>All Students</u></h1>
    <section style="float: right;">
        <?php if(session('message')): ?>
            <h3 class="text-success fw-bold"><?php echo e(session('message')); ?></h3>
        <?php endif; ?>
    </section>
</div>
<div class="table table-responsive">
    <table class="table table-bordered">
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Image</th>
            <th>Action</th>
        </tr>
        <?php $__currentLoopData = $data->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->name); ?></td>
            <td><?php echo e($item->email); ?></td>
            <td><?php echo e($item->phone); ?></td>
            <td>
                <img src="uploads/<?php echo e($item->image); ?>" alt="Image" height="68px" width="68px">
            </td>
            <td>
                <a href="<?php echo e(url('/edit')); ?><?php echo e($item->id); ?>" class="btn btn-sm btn-success shadow-none">UPDATE</a>
                <a href="<?php echo e(url('/delete')); ?><?php echo e($item->id); ?>" class="btn btn-sm btn-danger shadow-none">DELETE</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php_tranning\laravel\test\resources\views/show.blade.php ENDPATH**/ ?>